在使用中可能（肯定）会被某60等杀毒软件误报。。。
毕竟它是开源的，
https://github.com/Rechared7230/File_by_Rechared